<?php
sleep(610)
?>This content took 10m10s to deliver.  Congratulations, you didn't time out!
