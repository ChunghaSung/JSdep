#include <CoreServices/CoreServices.r>

// Plugin info
resource 'STR#' (126) { {
    "Tests NPN_Invoke()",
    "NPN_Invoke Test Plug-In"
} };

// MIME Type descriptions
resource 'STR#' (127) { {
    "NPN_Invoke test"
} };

// MIME Types
resource 'STR#' (128) { {
    "test/npn-invoke"
} };
