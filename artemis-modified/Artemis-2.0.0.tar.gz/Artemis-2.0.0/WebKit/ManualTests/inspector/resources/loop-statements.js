var i;
var a;

function initialize()
{
    i = false;
}

function condition()
{
    return !i;
}

function increment()
{
    i = !i;
}

function statement()
{
    a = i;
}
