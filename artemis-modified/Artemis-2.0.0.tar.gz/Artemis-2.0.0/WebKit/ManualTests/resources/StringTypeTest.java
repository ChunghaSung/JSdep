import java.applet.*;

public class StringTypeTest extends Applet {
    public String getString() {
        return new String("hello");
    }
}