var test = document.body;
this.will.be.an.error = 1;

function test() {
    return 42;
}
