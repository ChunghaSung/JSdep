import java.applet.Applet;
import java.awt.Color;
import java.awt.Component;

public class CheckerApplet extends Applet
{

    public boolean checkVersion()
    {
        return true;
    }

    public void start()
    {
        setBackground(new Color(255, 255, 255));
    }

    public CheckerApplet()
    {
    }
}
