console.info("Test console.info");
console.log("Test console.log");
console.warn("Test console.warn");
console.error("Test console.error");
console.time("Test console.time");
console.timeEnd("Test console.time");
console.count("Test console.count");
console.assert(false, "Test console.assert");
